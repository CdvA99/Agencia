/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author vanegas
 */
public class Proceso {

    public Proceso() {
    }

    private int Id;
    private float valorV;
    private String Nombre;
    private int Telefono;
    private int Edad;
    private char AcumulacionMillas;
       
       
     public Proceso(int Id, float valorV, int Edad, String Nombre, char AcumulacionMillas, int Telefono){
        this.Id = Id;
        this.Edad = Edad;
        this.Nombre = Nombre;
        this.valorV = valorV;
        this.Telefono = Telefono;
        this.AcumulacionMillas = AcumulacionMillas;
        
    }

    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public float getValorV() {
        return valorV;
    }

    public void setValorV(float valorV) {
        this.valorV = valorV;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public int getTelefono() {
        return Telefono;
    }

    public void setTelefono(int Telefono) {
        this.Telefono = Telefono;
    }

    public int getEdad() {
        return Edad;
    }

    public void setEdad(int Edad) {
        this.Edad = Edad;
    }

    public char getAcumulacionMillas() {
        return AcumulacionMillas;
    }

    public void setAcumulacionMillas(char AcumulacionMillas) {
        this.AcumulacionMillas = AcumulacionMillas;
    }

    

   public float ValorViaje(){
       return(float) (float) ((valorV)=1000000);
   }
   
   public float Descuento(){
       return(float) (float) ((valorV)%20);
   }
   
   
   
  
   
   
   public void AcumulacionDeMillas(){
       if(AcumulacionMillas<=0){
           System.out.println("Al tener Acumulacion de millas usted tiene un descuento en su viaje");
       }
       else{
           System.out.println("No tiene descuento, el precio por su viaje es normal");
       }
   }
}
